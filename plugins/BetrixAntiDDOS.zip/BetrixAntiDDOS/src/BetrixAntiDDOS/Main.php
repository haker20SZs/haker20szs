<?php

declare(strict_types=1);

namespace BetrixAntiDDOS;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Utils;
use pocketmine\utils\Config;
use pocketmine\utils\Internet;
use pocketmine\utils\Timezone;
use pocketmine\scheduler\CallbackTask;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\inventory\ContainerInventory;
use pocketmine\network\mcpe\protocol\BatchPacket;
use pocketmine\network\mcpe\protocol\LoginPacket;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\network\mcpe\protocol\MovePlayerPacket;
use pocketmine\network\mcpe\protocol\DataPacket;
use pocketmine\network\mcpe\protocol\PlayStatusPacket;

class Main extends PluginBase implements Listener {

	public const SKIN_WIDTH_MAP = [

        64 * 32 * 4 => 64,
        64 * 64 * 4 => 64,
        128 * 128 * 4 => 128,

    ];

    public const SKIN_HEIGHT_MAP = [

        64 * 32 * 4 => 32,
        64 * 64 * 4 => 64,
        128 * 128 * 4 => 128,

    ];

    private const MIN_PHP_VERSION = "8.0"; // Минимальная версия php

	private $data = [];
	private $text = "BetrixAntiDDOS - vk.com/love_2077";
	private $blackList = [];

	public $fixdrop = array();

	public function onEnable() {

		date_default_timezone_set(Timezone::get());

		$this->onInfo();

		$this->getServer()->getPluginManager()->registerEvents($this, $this);

		if (version_compare(self::MIN_PHP_VERSION, PHP_VERSION) > 0) {

			$this->getLogger()->error("Минимальная версия PHP для запуска плагина " . self::MIN_PHP_VERSION . ",");
			$this->getLogger()->error("Версия на которой запущен плагин " . PHP_VERSION . " не подходит для работы плагина.");
			$this->getServer()->getPluginManager()->disablePlugins();

			return;

		}

		$this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask(array($this, "onCheckDDoSAttempts")), 20 * 60);

	}

	public function onInfo() {

        $this->getLogger()->info('

            ███████████████████████████████████
            █────█─███────█────█────█───█────█
            ███──█─███─██─█─████─████─███─██─█
            ██──██─███─██─█─█──█─█──█───█────█
            █──███─███─██─█─██─█─██─█─███─█─██
            █────█───█────█────█────█───█─█─██
            ███████████████████████████████████

    Купить плагин или продать душу можно здесь - vk.com/love_2077
    Чтобы получить скидку в размере 30% напишите мне в вк (Скидка - ZLO)
        ');

    }

	public function onJoin(PlayerJoinEvent $event) {

		if (!(PlayStatusPacket::LOGIN_SUCCESS == 0)) {

			$event->getPlayer()->close("", "Не удалось пройти проверку");

		} elseif(!(PlayStatusPacket::PLAYER_SPAWN == 3)) {

			$event->getPlayer()->close("", "Не удалось заспавнить Entity");

		}

		$this->fixdrop[strtolower($event->getPlayer()->getName())] = time() + 2;
		$this->onCheckSkin($event);

	}

    public function onPing(PlayerPreLoginEvent $event) {

    	$cid = $event->getPlayer()->getClientId();
    	$ip = $event->getPlayer()->getAddress();

    	$reasonrand = array("disconnectionScreen.invalidName", "disconnectionScreen.invalidClientId", "disconnectionScreen.invalidSkin", "disconnectionScreen.invalidDevice", "disconnectionScreen.invalidInputMode", "disconnectionScreen.invalidGameVersion", "disconnectionScreen.invalidTenantId", "disconnectionScreen.invalidClient", "disconnectionScreen.invalidSkinData", "disconnectionScreen.invalidConnect", "disconnectionScreen.invalidUIP", "disconnectionScreen.invalidScale");
    	$reasonr = array_rand($reasonrand);
    	$reason = $reasonrand[$reasonr];
    	$upload = round($this->getServer()->getNetwork()->getUpload() / 1024, 2);
    	$download = round($this->getServer()->getNetwork()->getDownload() / 1024, 2);

    	$ping = $event->getPlayer()->getPing();

    	if ($ping > 1000) {

    		$event->getPlayer()->close("", "$reason");

    		$this->getLogger()->info("Игрок " . $ip . " пытался запустить атаку на сервер с бота. Пинг бота составил " . $ping . "ms - Upload " . $upload . " Download " . $download . " kB/s");

    	} elseif ($cid === 0) {

            $reasonrand = array("disconnectionScreen.invalidName", "disconnectionScreen.invalidClientId", "disconnectionScreen.invalidSkin", "disconnectionScreen.invalidDevice", "disconnectionScreen.invalidInputMode", "disconnectionScreen.invalidGameVersion", "disconnectionScreen.invalidTenantId", "disconnectionScreen.invalidClient", "disconnectionScreen.invalidSkinData", "disconnectionScreen.invalidConnect", "disconnectionScreen.invalidUIP", "disconnectionScreen.invalidScale");
            $reasonr = array_rand($reasonrand);
            $reason = $reasonrand[$reasonr];

            $event->getPlayer()->close("", "$reason");

        }

    }

    public function onCheckSkin($event) {

        $skinData = $event->getPlayer()->getSkinData();
        $size = strlen($skinData);
        $width = self::SKIN_WIDTH_MAP[$size];
        $height = self::SKIN_HEIGHT_MAP[$size];
		$pos = -1;
		$pixelsNeeded = (int)((100 - 70) / 100 * ($width * $height));

		for ($y = 0; $y < $height; $y++) {

			for ($x = 0; $x < $width; $x++) {

				if (ord($skinData[$pos += 4]) === 255) {

					if (--$pixelsNeeded === 0) {

						return true;

					}

				}

			}

		}

		$event->getPlayer()->close("", "Нельзя использовать невидимые скины");

		return false;

    }

	public function onFixDrop(PlayerDropItemEvent $event) {

		$username = strtolower($event->getPlayer()->getName());

	    if ($this->fixdrop[$username] - time() <= 0) {

	    	$this->fixdrop[$username] = time() + 2;

	    } else {

	    	$event->setCancelled();

	    }

	}
	
	public function onDamage(EntityDamageEvent $event) {

		if ($event instanceof EntityDamageByEntityEvent) {

			$entity = $event->getEntity();
			$damager = $event->getDamager();

			if ($damager instanceof Player && ($event->getCause() == EntityDamageEvent::CAUSE_ENTITY_ATTACK)) {

				if ($damager->distance($entity) > 4) {

					$event->setCancelled();

				}

			}

		}

	}

	public function onDataPacket(DataPacketReceiveEvent $event) {

		$pk = $event->getPacket();

		if ($event->getPacket()::NETWORK_ID == ProtocolInfo::LOGIN_PACKET) {

            $ip = $event->getPlayer()->getAddress();

            if (!isset($this->count[$ip])) {

                $this->count[$ip] = 1;
            
            } else {

                $this->count[$ip]++;

            }

            if ($this->count[$ip] >= 3) {

                foreach ($this->getServer()->getOnlinePlayers() as $player) {

                    if ($player instanceof Player && $player->isOnline()) {

                        if ($player->getAddress() == $ip) {

                            $player->close("", "Нельзя использовать больше 3 устройств для одного IP адреса");

                        }

                    }

                }

                exec("sudo iptables -A INPUT -s " . $ip . " -j DROP");

                $this->getServer()->getNetwork()->blockAddress($ip, PHP_INT_MAX);
                $this->getServer()->getIPBans()->addBan($ip);

            }
        
        }

		if ($pk instanceof MovePlayerPacket) {

			$maxX = $pk->x > $event->getPlayer()->x ? $pk->x : $event->getPlayer()->x;
			$minX = $pk->x < $event->getPlayer()->x ? $pk->x : $event->getPlayer()->x;
			$maxZ = $pk->z < $event->getPlayer()->z ? $pk->z : $event->getPlayer()->z;
			$minZ = $pk->z < $event->getPlayer()->z ? $pk->z : $event->getPlayer()->z;
			$maxY = $pk->y < $event->getPlayer()->y ? $pk->y : $event->getPlayer()->y;
			$minY = $pk->y < $event->getPlayer()->y ? $pk->y : $event->getPlayer()->y;

			if ($maxX - $minX > 20 || $maxZ - $minZ > 20 || $maxY - $minY > 20) {

				$event->setCancelled();

			}

		}

		if ($pk instanceof LoginPacket) {

			$packet = (array)$pk;

			$server_address = file_get_contents("http://api.ipify.org/");
			$server_port = $this->getServer()->getPort();

			$names = ["Unknown", "Android", "iOS", "MacOS", "FireOS", "GearVR", "HoloLens", "Windows 10", "Windows", "Dedicated", "Orbis", "NX"];
			$device = $names[$packet['clientData']['DeviceOS']];

			$upload = round($this->getServer()->getNetwork()->getUpload() / 1024, 2);
			$download = round($this->getServer()->getNetwork()->getDownload() / 1024, 2);

			if ($device == $names["0"]) {

				$event->getPlayer()->close("", "Данное устройство запрещено на сервере!");

				$event->setCancelled();

			}

			if ($packet['clientId'] === 0) {

				$event->setCancelled();
				$event->getPlayer()->close("", "Отключите Toolbox!");

			}

			if ($packet['clientData']['LanguageCode'] == null) {

				$event->setCancelled();
				$event->getPlayer()->close("", "Нету языкового пакета!");

			}

		}

		return true;

	}

	public function onBreak(BlockBreakEvent $event) {

		if (isset($this->data[$playerName = $event->getPlayer()->getName()])) {

			if (abs(microtime(true) - $this->data[$playerName]) <= 1) {

				$event->setCancelled();

			} else {

				unset($this->data[$playerName]);

			}

		}
	
	}
	
	public function onQuery(QueryRegenerateEvent $event) {

		$event->setServerName($this->text);
		$event->setListPlugins([]);
		$event->setPlayerList([]);
		$event->setExtraData([]);
		$event->setPlugins([]);

	}

	public function onCheckDDoSAttempts() {

        $log_file = "/var/log/apache2/access.log";

        if (!file_exists($log_file)) {

            return;

        }

        $file_handle = fopen($log_file, "r");

        while (!feof($file_handle)) {

            $line = fgets($file_handle);

            if (empty($line)) {

                continue;

            }

            if (strpos($line, 'GET /') !== false || strpos($line, 'POST /') !== false || strpos($line, 'HEAD /') !== false) {

                $fields = explode(' ', $line);

                $ip = $fields[0];
                $date = $fields[3];
                $time_zone = $fields[4];
                $method = $fields[5];
                $request = $fields[6];

                $port = null;

                if (strcmp($method, 'GET') === 0 || strcmp($method, 'POST') === 0 || strcmp($method, 'HEAD') === 0) {

                    if (strpos($request, ':') !== false) {

                        $port = intval(substr($request, strpos($request, ':') + 1));

                    } else {

                        $port = 80;

                    }

                }

                if (!empty($ip) && !empty($port)) {

                    if (isset($this->blackList[$ip]) && in_array($port, $this->blackList[$ip])) {

                        foreach ($this->getServer()->getOnlinePlayers() as $player) {

                        	if ($player->getAddress() == $ip) {

                        		$player->close("", "Вы были отключены за предпринимаемые попытки DDoS-атаки!");

                        		exec("sudo iptables -A INPUT -s " . $ip . " -j DROP");

                        	}

                        }

                    }

                    if (!isset($this->blackList[$ip])) {

                        $this->blackList[$ip] = [];

                    }

                    array_push($this->blackList[$ip], $port);

                }
            }
        }

        fclose($file_handle);

    }

	public function onClose(InventoryCloseEvent $event) {

		if ($event->getInventory() instanceof ContainerInventory) {

			$this->data[$event->getPlayer()->getName()] = microtime(true);

		}

	}

	public function onInteract(PlayerInteractEvent $event) : void {

		if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) {

			if (empty($this->times_left[$event->getPlayer()->getName()]) || $this->times_left[$event->getPlayer()->getName()] <= time()) {

				$this->times_left[$event->getPlayer()->getName()] = time() + 0.3;

			} else {

				$event->setCancelled();

			}

		} elseif($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {

			if ($event->getBlock()->getId() == 96 || $event->getBlock()->getId() == 167) {

				if (empty($this->times_right[$event->getPlayer()->getName()]) || $this->times_right[$event->getPlayer()->getName()] <= time()) {

					$this->times_right[$event->getPlayer()->getName()] = time() + 0.5;

				} else {

					$event->setCancelled();

				}

			}

		}

	}

    public function onPlayerQuit(PlayerQuitEvent $event) {

        $ip = $event->getPlayer()->getAddress();

        if (isset($this->count[$ip])) {

            $this->count[$ip]--;

        }

        return true;

    }

}

?>